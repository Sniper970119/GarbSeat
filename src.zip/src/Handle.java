import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.*;

import javax.swing.*;
import java.io.File;
import java.io.IOException;

/**
 * Created by admin on 2017/12/24.
 */
public class Handle implements Runnable {
    private static Object lock = new Object();
    static boolean flag = true;

    @Override
    public void run() {
        long RunTime = System.currentTimeMillis();
        WebClient webClient = new WebClient();
        webClient.getOptions().setCssEnabled(false);
        webClient.getOptions().setJavaScriptEnabled(false);
        HtmlPage htmlPage = null;
        try {
            htmlPage = webClient.getPage("http://202.199.137.66/seat/(S(1sezvf3jylf250bjkjzdi4ic))/zwyd.aspx");
            //我 刚刚实验的时候没调用这个方法 我觉得浪费时间 把开启这个线程的方法直接替换成output
            /*if ((System.currentTimeMillis() - RunTime) >= 10000) {
                try {
                    this.wait();//这里是暂停线程吗？嗯   10秒没有运行完就自己停止。。。 代码不太对景。。。

                } catch (InterruptedException e) {
                    JOptionPane.showMessageDialog(null, "线程终止异常", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }*/
            HtmlForm form = htmlPage.getFormByName("form1");
            HtmlSubmitInput button = form.getInputByValue("预订报名");
            HtmlTextInput textField = form.getInputByName("TextBox1");
            textField.setValueAttribute("1518140218");
            HtmlPage nextPage = button.click();
            String result = nextPage.asXml();
            if ((result.indexOf("请勿重复报名")) != -1) {
                synchronized (lock) {
                    while (true) {
                        if (flag == false) {
                            break;
                        } else {
                            return;
                        }
                    }
                }
            }
            HtmlImage valicode = nextPage.getHtmlElementById("ImageCheck");
            valicode.saveAs(new File("ValidateCode.aspx"));
            valicode.saveAs(new File("valicode.jpg"));

            HtmlPage htmlPage2 = nextPage;
            HtmlForm form2 = htmlPage2.getFormByName("form1");
            HtmlTextInput textField2 = form2.getInputByName("TextBox1");
            HtmlSubmitInput button2 = form2.getInputByValue("提交");
            if ((System.currentTimeMillis() - RunTime) >= 10000) {
                try {
                    this.wait();
                } catch (InterruptedException e) {
                    JOptionPane.showMessageDialog(null, "线程终止异常", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
            }
            String code;
            code = new JudgeCode().run();
            System.out.println(code);
            textField2.setValueAttribute(code);
            HtmlPage nextPage2 = button2.click();
            String result2 = nextPage2.asXml();

            if ((result2.indexOf("恭喜，报名成功！")) != -1) {
                synchronized (lock) {
                    while (true) {
                        flag = true;
                        new JudgeState().HandleSuccess();
                        return;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
