/**
 * Created by admin on 2017/12/24.
 */
public class StartCon implements Runnable{

    @Override
    public void run() {
        long runTime = System.currentTimeMillis();
        JudgeState judgeState = new JudgeState();
        MainFrame mainFrame = MainFrame.getInstance();
        while (true) {
            if (!(judgeState.getStart())) {
                break;
            }
            //if (((System.currentTimeMillis() - runTime) >= 1000) ) {
            try{Thread.sleep(1000);}catch (Exception e){}//线程休眠的话应该这样写
            //我刚开始这个方法没用线程 所以用的System time  但是后来发现按钮一直是按下的就改成线程了 但是还是不行
            //头绪有点乱。但是我在想。。是不是你这个按钮绑定的写法不太对、

            runTime = System.currentTimeMillis();
            System.out.println("in..............................");
            if (!(judgeState.JudgeSuccess())){
                //new Thread(new Handle());
                System.out.println("55555");
                mainFrame.repaint();//但是还是不好用的 按钮没有被释放
            }


        }
    }
}
