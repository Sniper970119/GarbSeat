/**
 * Created by admin on 2017/12/24.
 */
public class Start {
    public static void main(String[] args){
        MainFrame a =MainFrame.getInstance();
        /*for (int i = 0; i < 99999999; i++) {
            for (int j = 0; j < 999999; j++) {
                a.repaint();
            }
        }*/
    }
}
