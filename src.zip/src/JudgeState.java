import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

import java.io.IOException;

/**
 * Created by admin on 2017/12/24.
 */
public class JudgeState {
    private boolean success = false;
    private boolean start = true;

    public void HandleSuccess(){
        this.success = true;
    }
    public boolean JudgeSuccess(){
        return success;
    }
    public boolean getStart(){
        return start;
    }
    public void setStart(){
        start = false;
    }

}
